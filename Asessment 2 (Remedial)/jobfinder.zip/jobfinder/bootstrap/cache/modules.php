<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\JobFinder\\Providers\\JobFinderServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\JobFinder\\Providers\\JobFinderServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);