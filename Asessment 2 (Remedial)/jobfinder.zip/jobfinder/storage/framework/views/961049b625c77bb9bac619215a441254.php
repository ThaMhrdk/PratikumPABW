

<?php $__env->startSection('title', 'Lamaran'); ?>

<?php $__env->startSection('content'); ?>
<?php /** @var \App\Models\User $user */ $user = Auth::user(); ?>
<div class="page-header">
    <h1><?php echo e($user->role === 'admin' ? 'Semua Lamaran' : 'Lamaran Saya'); ?></h1>
    <?php if($user->role === 'pelamar'): ?>
        <a href="<?php echo e(route('jobfinder.lamaran.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Buat Lamaran
        </a>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-body">
        <?php if($daftarLamaran->isEmpty()): ?>
            <div class="empty-state">
                <i class="fas fa-file-alt"></i>
                <p>Belum ada lamaran</p>
            </div>
        <?php else: ?>
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <?php if($user->role === 'admin'): ?><th>Pelamar</th><?php endif; ?>
                            <th>Posisi</th>
                            <th>Perusahaan</th>
                            <th>Tanggal</th>
                            <th>CV</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $daftarLamaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $lamaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i + 1); ?></td>
                                <?php if($user->role === 'admin'): ?>
                                    <td>
                                        <strong><?php echo e($lamaran->user->name); ?></strong>
                                        <br><small class="text-muted"><?php echo e($lamaran->user->email); ?></small>
                                    </td>
                                <?php endif; ?>
                                <td><?php echo e($lamaran->lowongan->posisi); ?></td>
                                <td><?php echo e($lamaran->lowongan->perusahaan); ?></td>
                                <td><?php echo e($lamaran->created_at->format('d M Y')); ?></td>
                                <td>
                                    <?php if($lamaran->cv_file): ?>
                                        <a href="<?php echo e(route('jobfinder.lamaran.download-cv', $lamaran)); ?>" class="btn btn-outline btn-sm">
                                            <i class="fas fa-download"></i>
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a href="<?php echo e(route('jobfinder.lamaran.show', $lamaran)); ?>" class="btn btn-outline btn-sm"><i class="fas fa-eye"></i></a>
                                        <?php if($user->role === 'pelamar' && $lamaran->user_id === Auth::id()): ?>
                                            <a href="<?php echo e(route('jobfinder.lamaran.edit', $lamaran)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                                        <?php endif; ?>
                                        <?php if($user->role === 'admin'): ?>
                                            <button class="btn btn-danger btn-sm btn-hapus" data-id="<?php echo e($lamaran->id); ?>"><i class="fas fa-trash"></i></button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$('.btn-hapus').on('click', function() {
    var id = $(this).data('id'), row = $(this).closest('tr');
    Swal.fire({
        title: 'Hapus Lamaran?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '/module/lamaran/' + id,
                type: 'DELETE',
                success: function() {
                    Swal.fire('Berhasil!', 'Lamaran dihapus.', 'success');
                    row.fadeOut();
                }
            });
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('jobfinder::layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Program Files\XAMPP\htdocs\PHP\PratikumPABW\Pratikum-PABW\Asessment 2 (Remedial)\jobfinder\Modules/JobFinder\resources/views/lamaran/index.blade.php ENDPATH**/ ?>