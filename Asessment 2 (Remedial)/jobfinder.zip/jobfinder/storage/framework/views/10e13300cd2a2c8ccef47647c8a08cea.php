

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<?php /** @var \App\Models\User $user */ $user = Auth::user(); ?>
<div class="page-header">
    <h1>Selamat Datang, <?php echo e($user->name); ?>!</h1>
    <a href="<?php echo e(route('jobfinder.lowongan.index')); ?>" class="btn btn-primary">
        <i class="fas fa-search"></i> Cari Lowongan
    </a>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <h3><?php echo e($statistik['total_lowongan']); ?></h3>
        <p><i class="fas fa-briefcase"></i> Lowongan Tersedia</p>
    </div>
    <div class="stat-card">
        <h3><?php echo e($statistik['lamaran_saya']); ?></h3>
        <p><i class="fas fa-paper-plane"></i> Lamaran Terkirim</p>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <div class="card-header"><i class="fas fa-fire"></i> Lowongan Terbaru</div>
        <div class="card-body">
            <?php $__empty_1 = true; $__currentLoopData = $lowonganTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lowongan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div style="padding: 0.75rem 0; border-bottom: 1px solid #e2e8f0;">
                    <div style="display: flex; justify-content: space-between; align-items: start;">
                        <div>
                            <strong><?php echo e($lowongan->posisi); ?></strong>
                            <p class="text-muted" style="font-size: 0.8rem; margin: 0.25rem 0;"><?php echo e($lowongan->perusahaan); ?></p>
                            <?php if($lowongan->gaji): ?>
                                <span class="badge badge-success">Rp <?php echo e(number_format($lowongan->gaji, 0, ',', '.')); ?></span>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(route('jobfinder.lamaran.create', ['lowongan' => $lowongan->id])); ?>" class="btn btn-success btn-sm">
                            <i class="fas fa-paper-plane"></i>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted text-center">Belum ada lowongan</p>
            <?php endif; ?>
            <div class="mt-2">
                <a href="<?php echo e(route('jobfinder.lowongan.index')); ?>" class="btn btn-outline btn-sm">Lihat Semua <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><i class="fas fa-file-alt"></i> Lamaran Saya</div>
        <div class="card-body">
            <?php $__empty_1 = true; $__currentLoopData = $lamaranSayaTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lamaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div style="padding: 0.75rem 0; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <strong><?php echo e($lamaran->lowongan->posisi); ?></strong>
                        <p class="text-muted" style="font-size: 0.8rem; margin: 0;"><?php echo e($lamaran->lowongan->perusahaan); ?></p>
                    </div>
                    <span class="badge badge-<?php echo e($lamaran->status === 'diterima' ? 'success' : ($lamaran->status === 'ditolak' ? 'danger' : 'warning')); ?>"><?php echo e(ucfirst($lamaran->status)); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted text-center">Belum ada lamaran</p>
            <?php endif; ?>
            <div class="mt-2">
                <a href="<?php echo e(route('jobfinder.lamaran.index')); ?>" class="btn btn-outline btn-sm">Lihat Semua <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('jobfinder::layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Program Files\XAMPP\htdocs\PHP\PratikumPABW\Pratikum-PABW\Asessment 2 (Remedial)\jobfinder\Modules/JobFinder\resources/views/dashboard/pelamar.blade.php ENDPATH**/ ?>