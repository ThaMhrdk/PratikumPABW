

<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>Dashboard Admin</h1>
    <a href="<?php echo e(route('jobfinder.lowongan.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Tambah Lowongan
    </a>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <h3><?php echo e($statistik['total_lowongan']); ?></h3>
        <p><i class="fas fa-briefcase"></i> Total Lowongan</p>
    </div>
    <div class="stat-card">
        <h3><?php echo e($statistik['total_lamaran']); ?></h3>
        <p><i class="fas fa-file-alt"></i> Total Lamaran</p>
    </div>
    <div class="stat-card">
        <h3><?php echo e($statistik['total_pelamar']); ?></h3>
        <p><i class="fas fa-users"></i> Total Pelamar</p>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <div class="card-header"><i class="fas fa-briefcase"></i> Lowongan Terbaru</div>
        <div class="card-body">
            <?php $__empty_1 = true; $__currentLoopData = $lowonganTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lowongan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div style="padding: 0.75rem 0; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <strong><?php echo e($lowongan->posisi); ?></strong>
                        <p class="text-muted" style="font-size: 0.8rem; margin: 0;"><?php echo e($lowongan->perusahaan); ?></p>
                    </div>
                    <a href="<?php echo e(route('jobfinder.lowongan.edit', $lowongan)); ?>" class="btn btn-outline btn-sm"><i class="fas fa-edit"></i></a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted text-center">Belum ada lowongan</p>
            <?php endif; ?>
            <div class="mt-2">
                <a href="<?php echo e(route('jobfinder.lowongan.index')); ?>" class="btn btn-outline btn-sm">Lihat Semua <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><i class="fas fa-file-alt"></i> Lamaran Terbaru</div>
        <div class="card-body">
            <?php $__empty_1 = true; $__currentLoopData = $lamaranTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lamaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div style="padding: 0.75rem 0; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <strong><?php echo e($lamaran->user->name); ?></strong>
                        <p class="text-muted" style="font-size: 0.8rem; margin: 0;"><?php echo e($lamaran->lowongan->posisi); ?></p>
                    </div>
                    <span class="badge badge-<?php echo e($lamaran->status === 'diterima' ? 'success' : ($lamaran->status === 'ditolak' ? 'danger' : 'warning')); ?>"><?php echo e(ucfirst($lamaran->status)); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted text-center">Belum ada lamaran</p>
            <?php endif; ?>
            <div class="mt-2">
                <a href="<?php echo e(route('jobfinder.lamaran.index')); ?>" class="btn btn-outline btn-sm">Lihat Semua <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('jobfinder::layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Program Files\XAMPP\htdocs\PHP\PratikumPABW\Pratikum-PABW\Asessment 2 (Remedial)\jobfinder\Modules/JobFinder\resources/views/dashboard/admin.blade.php ENDPATH**/ ?>