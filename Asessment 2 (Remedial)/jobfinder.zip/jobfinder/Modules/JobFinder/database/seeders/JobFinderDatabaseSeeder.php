<?php

namespace Modules\JobFinder\Database\Seeders;

use Illuminate\Database\Seeder;

class JobFinderDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
