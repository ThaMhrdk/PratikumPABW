<?php

return [
    'name' => 'JobFinder',
];
